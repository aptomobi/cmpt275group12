//
//  SettingsVC.m
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "SettingsVC.h"
#import "AccountSettingsVC.h"
#import "EmergencyContactVC.h"

@interface SettingsVC () <UITableViewDataSource, UITableViewDelegate>

@end

@implementation SettingsVC
{
    UITableView *_tableSettings;
    NSMutableArray *_arraySettings;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    _arraySettings = [[NSMutableArray alloc]initWithObjects:@"Account",@"Emergency Contact", nil];
    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnBack = [UIFunction createButton:CGRectMake(0, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:nil titleColor:nil];
    [_btnBack addTarget:self action:@selector(func_BackButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnBack];
    
    UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(_btnBack.frame.size.width+_btnBack.frame.origin.x+10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] isLogo:NO];
    [_viewHeader addSubview:_imgViewLogo];
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Settings" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];

    
    // UITable View which contains all Field
    _tableSettings = [self createTableView:CGRectMake(0,_viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height-_viewHeader.frame.size.height-_viewHeader.frame.origin.y) backgroundColor:[UIColor whiteColor]];
    _tableSettings.showsVerticalScrollIndicator = YES;
    _tableSettings.layer.cornerRadius = 5.0;
    [self.view addSubview:_tableSettings];
    
}


#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

#pragma mark
#pragma mark func_BackButton
-(void)func_BackButton
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark
#pragma mark Table View Data Source and Delegates
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_arraySettings count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    
    
    UILabel *_lblTableCell = [UIFunction createLable:CGRectMake(20, 0, 200, frame.size.height) bckgroundColor:[UIColor clearColor] title:[_arraySettings objectAtIndex:indexPath.row] font:[UIFont fontWithName:miscoRegular size:16.0] titleColor:[UIColor blackColor]];
    [cell.contentView addSubview:_lblTableCell];

    
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(_lblTableCell.frame.origin.x, frame.size.height-1, tableView.frame.size.width, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) // account
    {
        AccountSettingsVC *_account = [[AccountSettingsVC alloc]init];
        [self.navigationController pushViewController:_account animated:YES];
    }
    else if (indexPath.row == 1) // emergency contact
    {
        EmergencyContactVC *emergency = [[EmergencyContactVC alloc]init];
        [self.navigationController pushViewController:emergency animated:YES];
    }
}





- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
