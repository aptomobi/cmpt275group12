//
//  SicknessPlotterVC.m
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "SicknessPlotterVC.h"
#import "HealthAlertsVC.h"
#import "MyPillVC.h"
#import "SideMenu.h"
#import "CustomFooterView.h"
#import "SettingsVC.h"
#import <ResearchKit/ResearchKit.h>



@interface SicknessPlotterVC () <sideMenuProtocol, customFooterMethod, UIScrollViewDelegate, ORKTaskViewControllerDelegate, UIPickerViewDataSource,UIPickerViewDelegate>

@end

@implementation SicknessPlotterVC
{
    // all button and contents on this scene
    SideMenu *_viewSideMenu;
    CustomFooterView *footerView;
    
    UIView *_backgroundViewForSurveyAndGraph;
    UIButton *_btnSurvey;
    UIButton *_btnGraph;
    UIView *_whiteLineView;
    UIScrollView *sicknessPlotterPageScroll;
    BOOL isSurveyVisible;
    
    UIView *_viewForSurvey;
    UIView *_viewForGraph;
    NSString *surveyResult;
    // array to store infected rate on each location
    NSMutableArray *_arrayToPlotGraph;
    UILabel *_lblSelectWeek;

    UIView *_viewSelectWeekPicker;
    NSArray *_arrayWeeks;



}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [footerView changeImage:@"3"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // on off switch
    isSurveyVisible = YES;
    // init array to draw
    _arrayToPlotGraph = [[NSMutableArray alloc]init];
    // array for picker
    _arrayWeeks = [NSArray arrayWithObjects:@"1 week",@"2 weeks",@"3 weeks", nil];

    // design and add views
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnSideMenu = [UIFunction createButton:CGRectMake(10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] title:nil font:nil titleColor:nil];
    [_btnSideMenu addTarget:self action:@selector(func_SideMenuButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnSideMenu];
    
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Sickness Plotter" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];
    
    // show footview
    [footerView removeFromSuperview];
    footerView = nil;
    footerView = [[CustomFooterView alloc]init];
    footerView.frame = CGRectMake(0, self.view.frame.size.height-49, self.view.frame.size.width, 49);
    [footerView setBackgroundColor:[UIColor colorWithRed:247.0/255 green:247.0/255 blue:247.0/255 alpha:1.0]];
    footerView.footerDelegate=self;
    [self.view addSubview:footerView];
    [footerView changeImage:@"3"];

    
    
    // Scrollable View
    [_backgroundViewForSurveyAndGraph removeFromSuperview];
    _backgroundViewForSurveyAndGraph = nil;
    _backgroundViewForSurveyAndGraph = [UIFunction createUIViews:CGRectMake(0, _viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, 50) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    _backgroundViewForSurveyAndGraph.layer.shadowColor = [UIColor grayColor].CGColor;
    _backgroundViewForSurveyAndGraph.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    _backgroundViewForSurveyAndGraph.layer.shadowOpacity = 1.0;
    _backgroundViewForSurveyAndGraph.layer.shadowRadius = 2.0;
    [self.view addSubview:_backgroundViewForSurveyAndGraph];
    
    // add survey tap button
    [_btnSurvey removeFromSuperview];
    _btnSurvey = nil;
    _btnSurvey = [UIFunction createButton:CGRectMake(0, 0, _backgroundViewForSurveyAndGraph.frame.size.width/2.0, 48) bckgroundColor:[UIColor clearColor] image:nil title:@"Survey" font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
    [_btnSurvey addTarget:self action:@selector(func_SurveyButtonFunction) forControlEvents:UIControlEventTouchUpInside];
    [_backgroundViewForSurveyAndGraph addSubview:_btnSurvey];
    
    // add graph tap button
    [_btnGraph removeFromSuperview];
    _btnGraph = nil;
    _btnGraph = [UIFunction createButton:CGRectMake(_btnSurvey.frame.size.width+_btnSurvey.frame.origin.x, 0, _backgroundViewForSurveyAndGraph.frame.size.width/2.0, 49) bckgroundColor:[UIColor clearColor] image:nil title:@"Graph" font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
    [_btnGraph addTarget:self action:@selector(func_GraphButtonFunction) forControlEvents:UIControlEventTouchUpInside];
    [_backgroundViewForSurveyAndGraph addSubview:_btnGraph];
    
    // current indicator
    _whiteLineView = [[UIView alloc]init];
    _whiteLineView.frame = CGRectMake(0, 48, _backgroundViewForSurveyAndGraph.frame.size.width/2.0, 2);
    _whiteLineView.backgroundColor = [UIColor whiteColor];
    [_backgroundViewForSurveyAndGraph addSubview:_whiteLineView];
    
    
    sicknessPlotterPageScroll=[[UIScrollView alloc]initWithFrame:CGRectMake(0, _backgroundViewForSurveyAndGraph.frame.size.height+_backgroundViewForSurveyAndGraph.frame.origin.y+2, self.view.frame.size.width, footerView.frame.origin.y-_backgroundViewForSurveyAndGraph.frame.size.height-_backgroundViewForSurveyAndGraph.frame.origin.y-2)];
    sicknessPlotterPageScroll.backgroundColor=[UIColor clearColor];
    sicknessPlotterPageScroll.pagingEnabled=TRUE;
    sicknessPlotterPageScroll.delegate=self;
    sicknessPlotterPageScroll.tag=857412586;
    self.automaticallyAdjustsScrollViewInsets = NO;
    sicknessPlotterPageScroll.bounces = NO;
    sicknessPlotterPageScroll.showsHorizontalScrollIndicator=NO;
    sicknessPlotterPageScroll.showsVerticalScrollIndicator=NO;
    [sicknessPlotterPageScroll setContentOffset:CGPointMake(self.view.frame.size.width, 0) animated:NO];
    [sicknessPlotterPageScroll setContentSize:CGSizeMake(self.view.frame.size.width*2, sicknessPlotterPageScroll.frame.size.height)];
    [self.view addSubview:sicknessPlotterPageScroll];
    [sicknessPlotterPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width,sicknessPlotterPageScroll.frame.size.height) animated:YES];

    
    
    [_viewForSurvey removeFromSuperview];
    _viewForSurvey = nil;
    _viewForSurvey = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, sicknessPlotterPageScroll.frame.size.height) bckgroundColor:[UIColor clearColor]];
    [sicknessPlotterPageScroll addSubview:_viewForSurvey];
    
    // "start survey" button
    UIButton *_btnSurveyStart = [UIFunction createButton:CGRectMake(50, _viewForSurvey.frame.size.height/2.0-25.0, _viewForSurvey.frame.size.width-100, 50) bckgroundColor:[UIColor clearColor] image:nil title:@"Start Survey" font:[UIFont fontWithName:miscoRegular size:16.0] titleColor:[UIColor blackColor]];
    _btnSurveyStart.layer.cornerRadius = 5;
    _btnSurveyStart.layer.borderWidth = 2.0;
    _btnSurveyStart.layer.borderColor = [UIColor colorWithRed:60.0/255 green:60.0/255 blue:60.0/255 alpha:1.0].CGColor;
    [_btnSurveyStart addTarget:self action:@selector(func_StartSurvey) forControlEvents:UIControlEventTouchUpInside];
    [_viewForSurvey addSubview:_btnSurveyStart];
    
    
    // view for graph
    [_viewForGraph removeFromSuperview];
    _viewForGraph = nil;
    _viewForGraph = [UIFunction createUIViews:CGRectMake(self.view.frame.size.width, 0, self.view.frame.size.width, sicknessPlotterPageScroll.frame.size.height) bckgroundColor:[UIColor clearColor]];
    [sicknessPlotterPageScroll addSubview:_viewForGraph];

    // draw week with picker and grey bacjground
    _lblSelectWeek = [UIFunction createLable:CGRectMake(20, 10, _viewForGraph.frame.size.width-40, 30) bckgroundColor:[UIColor clearColor] title:@"Select week" font:[UIFont fontWithName:miscoRegular size:16] titleColor:[UIColor lightGrayColor]];
    _lblSelectWeek.textAlignment = NSTextAlignmentCenter;
    _lblSelectWeek.userInteractionEnabled = true;
    
    UITapGestureRecognizer *tapToSelectWeek = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(func_SelectWeek)];
    [_lblSelectWeek addGestureRecognizer:tapToSelectWeek];
    [_viewForGraph addSubview:_lblSelectWeek];
    

    
    
    self.plotChart = [[ZFPlotChart alloc]initWithFrame:CGRectMake(0, 50, _viewForGraph.frame.size.width , _viewForGraph.frame.size.height-100)];
    [_viewForGraph addSubview:self.plotChart];

}

#pragma mark
#pragma mark *********************************************** Side Menu Delgates ***********************************************

-(void)func_SideMenuButton
{
    NSLog(@"func Side Menu Button");
    
    [_viewSideMenu removeFromSuperview];
    _viewSideMenu = nil;
    _viewSideMenu = [[SideMenu alloc]init];
    _viewSideMenu.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    _viewSideMenu.sideMenuDelegate=self;
    [self.view addSubview:_viewSideMenu];
}

-(void)func_SideMenu_RemoveSideMenu
{
    [UIView animateWithDuration:0.3 animations:^
     {
         [_viewSideMenu func_SideMenu_RemoveSideMenu];
     }
                     completion:^(BOOL finished)
     {
         _viewSideMenu = nil;
     }];
}




- (void)func_SideMenu_Settings
{
    NSLog(@"Settings Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInSettings) withObject:nil afterDelay:0.5];
}

- (void)func_SideMenu_LogOut
{
    NSLog(@"LogOut Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInLogOut) withObject:nil afterDelay:0.5];
}


-(void)func_DelayInSettings
{
    NSLog(@"func_DelayInSettings");
    SettingsVC *_settings = [[SettingsVC alloc]init];
    [self.navigationController pushViewController:_settings animated:YES];
}


-(void)func_DelayInLogOut
{
    NSLog(@"func_DelayInLogOut");
    
    UIAlertView *_alertLogOut = [[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to logout ?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    _alertLogOut.tag = 45410;
    [_alertLogOut show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 45410 && buttonIndex == 1)
    {
        [self.view endEditing:YES];
        
        NSString *_strEmailToServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"email"];
        NSString *_strPasswordoServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"password"];
        
        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/logoutV2.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:_strEmailToServer forKey:@"email"];
        [Request setPostValue:_strPasswordoServer forKey:@"password"];
        Request.tag = 4510221;
        [Request startAsynchronous];
    }
}


#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 4510221) // logout user
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSString *response = [[NSString alloc] initWithBytes:[[request responseData] bytes] length:[[request responseData] length] encoding:NSUTF8StringEncoding];
            NSLog(@"json to logout user %@",response);
            
            if ([response containsString:@"false0"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Incorrect Password"];
            }
            else if ([response containsString:@"false1"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Account doesn't exists."];
            }
            else
            {
                [appDelegate() functionToHandleInvalidAccessToken];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
    
    else if (request.tag == 98770002) // survey response
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSString *response = [[NSString alloc] initWithBytes:[[request responseData] bytes] length:[[request responseData] length] encoding:NSUTF8StringEncoding];
            NSLog(@"json to survey response  %@",response);
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
    else if (request.tag == 6545621) // survey response to plot graph
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json to survey response to plot graph %@",json);
            
            if ([json objectForKey:@"response"])
            {
                json = [json objectForKey:@"response"];
                // NSLog(@"LANDING PAGE VC __________>>>> %@", [[NSString alloc] initWithBytes:[[request responseData] bytes] length:[[request responseData] length] encoding:NSUTF8StringEncoding]);
                
                
                NSArray *_arrayInfected = [json valueForKey:@"arrayInfected"];
                _arrayInfected = [[_arrayInfected valueForKey:@"infected"]mutableCopy];
                
                [_arrayToPlotGraph removeAllObjects];
                for (int counetr=0; counetr<_arrayInfected.count; counetr++)
                {
                    NSInteger value = [[_arrayInfected objectAtIndex:counetr]integerValue]*1000;
                    [_arrayToPlotGraph addObject:[NSString stringWithFormat:@"%zd",value]];
                }
                
                //NSArray *time_left = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
                NSMutableArray *tempArray = [[NSMutableArray alloc]init];
                for (int counter = 0; counter <_arrayToPlotGraph.count; counter++)
                {
                    NSDictionary *dic = [[NSDictionary alloc]initWithObjectsAndKeys:
                                         [NSString stringWithFormat:@"%d",counter+1],@"time",
                                         [_arrayToPlotGraph objectAtIndex:counter],@"value",
                                         nil];
                    [tempArray addObject:dic];
                }
                
                
                NSLog(@"_arrayToPlotGraph %@",tempArray);
                
                NSArray *values;
                values = tempArray;
                
                NSOrderedSet *result = [NSOrderedSet orderedSetWithArray:values];
                
                self.plotChart.alpha = 0;
                // draw data
                [self.plotChart createChartWith:result];
                [UIView animateWithDuration:0.5 animations:^{
                    self.plotChart.alpha = 1.0;
                }];
            }
            else if ([json objectForKey:@"error"])
            {
                [UIFunction func_AlertWithTitle:@"Error" andMessage:[json objectForKey:@"error"]];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
}



#pragma mark ***********************************************************************************************************************



#pragma mark
#pragma mark *********************************************** Footer Delgates ***********************************************

- (void)myPillButtonFunction
{
    NSLog(@"myPillButtonFunction");
    
    MyPillVC *log = [[MyPillVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }
}

- (void)healthCanadaAlertsButtonFunction
{
    NSLog(@"healthCanadaAlertsButtonFunction");
    
    HealthAlertsVC *log = [[HealthAlertsVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }
}
-(void) sickPlottersButtonFunction
{
    NSLog(@"sickPlottersButtonFunction");
}



#pragma mark ***********************************************************************************************************************









#pragma mark
#pragma mark func_SurveyButtonFunction
-(void)func_SurveyButtonFunction
{
    NSLog(@"func_ScheduleButtonFunction");
    
    [self showWhiteLine:@"0"];
    [sicknessPlotterPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height) animated:YES];
}

#pragma mark
#pragma mark func_GraphButtonFunction
-(void)func_GraphButtonFunction
{
    NSLog(@"func_GraphButtonFunction");
    
    [self showWhiteLine:@"1"];
    [sicknessPlotterPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width*2,self.view.frame.size.height) animated:YES];
}



#pragma mark
#pragma mark Scroll View Delegates
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView1
{
    if(scrollView1.tag==857412586)
    {
        CGFloat pageWidth = scrollView1.frame.size.width;
        float fractionalPage = scrollView1.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        NSLog(@"page is %zd",page);
        
        if (page == 0)
        {
            [self showWhiteLine:@"0"];
            isSurveyVisible = YES;
        }
        else if (page == 1)
        {
            [self showWhiteLine:@"1"];
            isSurveyVisible = NO;
        }
    }
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView1
{
    if(scrollView1.tag==857412586)
    {
        CGFloat pageWidth = scrollView1.frame.size.width;
        float fractionalPage = scrollView1.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        NSLog(@"page is %zd",page);
        
        if (page == 0)
        {
            [self showWhiteLine:@"0"];
            isSurveyVisible = YES;
        }
        else if (page == 1)
        {
            [self showWhiteLine:@"1"];
            isSurveyVisible = NO;
        }
    }
}



#pragma mark
#pragma mark Show White Line
-(void)showWhiteLine: (NSString*)type
{
    if ([type isEqualToString:@"0"])
    {
        _whiteLineView.frame = CGRectMake(0, 48, self.view.frame.size.width/2.0, 2);
    }
    else
    {
        _whiteLineView.frame = CGRectMake(self.view.frame.size.width/2.0, 48, self.view.frame.size.width/2.0, 2);
    }
}



#pragma mark
#pragma mark func_StartSurvey And Research Kit Delegate
-(void)func_StartSurvey
{
    NSLog(@"func_StartSurvey");
    
    ORKBooleanAnswerFormat *boolFormat = [ORKBooleanAnswerFormat new];
    
    ORKQuestionStep *booleanStep =
    [[ORKQuestionStep alloc] initWithIdentifier:@"identifier"];
    booleanStep.title = @"Are you feeling ill?";
    booleanStep.answerFormat = boolFormat;
    booleanStep.optional = NO;
    // Create a task wrapping the boolean step.
    ORKOrderedTask *task =
    [[ORKOrderedTask alloc] initWithIdentifier:@"identifier1" steps:@[booleanStep]];
    
    ORKTaskViewController *taskViewController =
    [[ORKTaskViewController alloc] initWithTask:task taskRunUUID:nil];
    taskViewController.delegate = self;
    [self presentViewController:taskViewController animated:YES completion:nil];

}

- (void)taskViewController:(ORKTaskViewController *)taskViewController didFinishWithReason:(ORKTaskViewControllerFinishReason)reason error:(NSError *)error {
    
    switch (reason) {
        case ORKTaskViewControllerFinishReasonCompleted:
        {
            ORKTaskResult *taskResult = [taskViewController result];            
            ORKStepResult *feverStepResult = [taskResult stepResultForStepIdentifier:@"identifier"];
            ORKQuestionResult *feverQuestionResult = (ORKQuestionResult *)feverStepResult.firstResult;
            
            if ([feverQuestionResult isKindOfClass:[ORKBooleanQuestionResult class]])
            {
                ORKBooleanQuestionResult *booleanResult = (ORKBooleanQuestionResult *)feverQuestionResult;
                NSNumber *booleanAnswer = booleanResult.booleanAnswer;
                
                if (booleanAnswer)
                {
                    if (booleanAnswer.boolValue == 1)
                    {
                        NSLog(@"yes");
                        surveyResult = @"1";
                    }
                    else if (booleanAnswer.boolValue == 0)
                    {
                        NSLog(@"NO");
                        surveyResult = @"0";
                    }
                }
            }
            [self func_APICallToPostSurveyData];
        }
            // If any file results are expected, also zip up the outputDirectory.
            break;
        case ORKTaskViewControllerFinishReasonFailed:
        case ORKTaskViewControllerFinishReasonDiscarded:
            // Generally, discard the result.
            // Consider clearing the contents of the output directory.
            break;
        case ORKTaskViewControllerFinishReasonSaved:
            // Store the restoration data persistently for later use.
            // Normally, keep the output directory for when you will restore.
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];

 }

-(void)func_APICallToPostSurveyData
{
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    
    if (netStatus == NotReachable)
    {
        [UIFunction func_Alert_InternetUnavailable];
    }
    else
    {
        NSLog(@"Call API For Sign Up");
        [self.view endEditing:YES];
        
        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/plotin.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:@"BC" forKey:@"Location"];
        [Request setPostValue:@"flu" forKey:@"Desease"];
        [Request setPostValue:surveyResult forKey:@"isSick"];
        Request.tag = 98770002;
        [Request startAsynchronous];
    }
}


-(void)func_APICalltoGetGraphData
{
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    
    if (netStatus == NotReachable)
    {
        [UIFunction func_Alert_InternetUnavailable];
    }
    else
    {
        NSLog(@"Call API To Get Graph data");
        [self.view endEditing:YES];
        
        NSInteger days = [[NSString stringWithFormat:@"%@",_lblSelectWeek.text]integerValue]*7;
        
        
        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/plotoutV2.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:[[[NSUserDefaults standardUserDefaults] valueForKey:kLoginData] valueForKey:@"location"] forKey:@"location"];
        [Request setPostValue:[NSString stringWithFormat:@"%zd",days] forKey:@"rangein"];
        Request.tag = 6545621;
        [Request startAsynchronous];
    }
}


#pragma mark
#pragma mark func_SelectWeek
-(void)func_SelectWeek
{
    [self.view endEditing:YES];
    
    [_viewSelectWeekPicker removeFromSuperview];
    _viewSelectWeekPicker = nil;
    _viewSelectWeekPicker = [UIFunction createUIViews:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 246) bckgroundColor:[UIColor colorWithRed:218.0/255 green:222.0/255 blue:230.0/255 alpha:1.0]];
    [self.view addSubview:_viewSelectWeekPicker];
    
    
    UIButton *_btnDone = [UIFunction createButton:CGRectMake(_viewSelectWeekPicker.frame.size.width-70, 0, 70, 50) bckgroundColor:[UIColor clearColor] image:nil title:@"Done" font:[UIFont fontWithName:miscoBold size:16.0] titleColor:[UIColor colorWithRed:67.0/255 green:133.0/255 blue:245.0/255 alpha:1.0]];
    [_btnDone addTarget:self action:@selector(dismissInputControls) forControlEvents:UIControlEventTouchUpInside];
    [_viewSelectWeekPicker addSubview:_btnDone];
    
    
    UIPickerView *_locationPickerView =  [[UIPickerView alloc]init];
    _locationPickerView.frame = CGRectMake(0, _viewSelectWeekPicker.frame.size.height-216.0, self.view.frame.size.width, 216.0);
    _locationPickerView.delegate=self;
    _locationPickerView.dataSource=self;
    _locationPickerView.showsSelectionIndicator=YES;
    _locationPickerView.backgroundColor = [UIColor clearColor];
    _locationPickerView.tag = 1210;
    [_viewSelectWeekPicker addSubview:_locationPickerView];
    
    
    [UIView animateWithDuration:0.3 animations:^{
        
        _viewSelectWeekPicker.frame = CGRectMake(0, self.view.frame.size.height-246, self.view.frame.size.width, 246);
        
    } completion:^(BOOL finished) {
        
        _lblSelectWeek.text = [_arrayWeeks objectAtIndex:0];
        _lblSelectWeek.textColor = [UIColor blackColor];
    }];
    
    

}

-(void)dismissInputControls
{
    [self func_APICalltoGetGraphData];

    [UIView animateWithDuration:0.3 animations:^{
        
        _viewSelectWeekPicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 246);
        
    } completion:^(BOOL finished) {
        
        [_viewSelectWeekPicker removeFromSuperview];
        _viewSelectWeekPicker = nil;
    }];
}



#pragma mark
#pragma mark Picker View Data Source and Delegates
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        return _arrayWeeks.count;
    }
    return 0;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if(pickerView.tag==1210)
    {
        return 1;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        return [_arrayWeeks objectAtIndex:row];
    }
    return 0;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        _lblSelectWeek.text = [_arrayWeeks objectAtIndex:row];
        _lblSelectWeek.textColor = [UIColor blackColor];
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
