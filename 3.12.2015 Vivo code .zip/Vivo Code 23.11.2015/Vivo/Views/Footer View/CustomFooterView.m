//
//  CustomFooterView.m
//  Yada
//
//  Created by Sukhreet on 19/12/14.
//  Copyright (c) 2014 Sukhreet. All rights reserved.
//

#import "CustomFooterView.h"

@implementation CustomFooterView
{
    UIButton *myPillButton;
    UIButton *healthCanadaAlertButton;
    UIButton *sicknessPlotterButton;
}

@synthesize footerDelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backgroundColor = [UIColor colorWithRed:247.0/255 green:247.0/255 blue:247.0/255 alpha:1.0];
        self.frame = CGRectMake(0, 0, 375, 48);
        
        
        [myPillButton removeFromSuperview];
        myPillButton = nil;
        myPillButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [myPillButton setImage:[UIImage imageNamed:@"contact.png"] forState:UIControlStateNormal];
        [myPillButton setImage:[UIImage imageNamed:@"contact_sel.png"] forState:UIControlStateHighlighted];
        [myPillButton setTitle:@"My Pill" forState:UIControlStateNormal];
        myPillButton.titleLabel.font = [UIFont fontWithName:miscoBold size:13];
        [myPillButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [myPillButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateHighlighted];
        [myPillButton setBackgroundColor:[UIColor clearColor]];
        myPillButton.exclusiveTouch = YES;
        myPillButton.frame = CGRectMake(0, 0, self.frame.size.width/3.0, 48);
        [myPillButton addTarget:self action:@selector(myPillButtonFunction) forControlEvents:UIControlEventTouchUpInside];
        myPillButton.userInteractionEnabled = true;
        [self addSubview:myPillButton];
        
        
        [healthCanadaAlertButton removeFromSuperview];
        healthCanadaAlertButton = nil;
        healthCanadaAlertButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [healthCanadaAlertButton setImage:[UIImage imageNamed:@"recent.png"] forState:UIControlStateNormal];
        [healthCanadaAlertButton setImage:[UIImage imageNamed:@"recent_sel.png"] forState:UIControlStateHighlighted];
        [healthCanadaAlertButton setTitle:@"Health Alerts" forState:UIControlStateNormal];
        healthCanadaAlertButton.titleLabel.font = [UIFont fontWithName:miscoBold size:13];
        [healthCanadaAlertButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [healthCanadaAlertButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateHighlighted];
        [healthCanadaAlertButton setBackgroundColor:[UIColor clearColor]];
        healthCanadaAlertButton.exclusiveTouch = YES;
        healthCanadaAlertButton.frame = CGRectMake(myPillButton.frame.size.width+myPillButton.frame.origin.x, 0, self.frame.size.width/3.0, 48);
        [healthCanadaAlertButton addTarget:self action:@selector(healthCanadaAlertsButtonFunction) forControlEvents:UIControlEventTouchUpInside];
        healthCanadaAlertButton.userInteractionEnabled = true;
        [self addSubview:healthCanadaAlertButton];
        

        
        [sicknessPlotterButton removeFromSuperview];
        sicknessPlotterButton = nil;
        sicknessPlotterButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [sicknessPlotterButton setTitle:@"Plotter" forState:UIControlStateNormal];
        sicknessPlotterButton.titleLabel.font = [UIFont fontWithName:miscoBold size:13];
        [sicknessPlotterButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [sicknessPlotterButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateHighlighted];
        [sicknessPlotterButton setBackgroundColor:[UIColor clearColor]];
        sicknessPlotterButton.exclusiveTouch = YES;
        sicknessPlotterButton.frame = CGRectMake(healthCanadaAlertButton.frame.size.width+healthCanadaAlertButton.frame.origin.x, 0, self.frame.size.width/3.0, 48);
        [sicknessPlotterButton addTarget:self action:@selector(sickPlottersButtonFunction) forControlEvents:UIControlEventTouchUpInside];
        sicknessPlotterButton.userInteractionEnabled = true;
        [self addSubview:sicknessPlotterButton];

        
        
        myPillButton.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 10, -30);
        myPillButton.titleEdgeInsets = UIEdgeInsetsMake(30, -40, 0, 0);
        
        healthCanadaAlertButton.imageEdgeInsets = UIEdgeInsetsMake(0, 25, 10, -30);
        healthCanadaAlertButton.titleEdgeInsets = UIEdgeInsetsMake(30, -30, 0, 0);
        
        sicknessPlotterButton.imageEdgeInsets = UIEdgeInsetsMake(0, 5, 10, -30);
        sicknessPlotterButton.titleEdgeInsets = UIEdgeInsetsMake(30, -20, 0, 0);
        
        [sicknessPlotterButton setImage:[UIImage imageNamed:@"more_iPhone6_grey.png"] forState:UIControlStateNormal];
        [sicknessPlotterButton setImage:[UIImage imageNamed:@"more_iPhone6.png"] forState:UIControlStateHighlighted];
    }
    
    return self;
}



#pragma mark myPillButtonFunction
-(void) myPillButtonFunction
{
    NSLog(@"myPillButtonFunction");
    [footerDelegate myPillButtonFunction];
}

#pragma mark healthCanadaAlertButtonFunction
-(void) healthCanadaAlertsButtonFunction
{
    NSLog(@"healthCanadaAlertButtonFunction");
    [footerDelegate healthCanadaAlertsButtonFunction];
}

#pragma mark sicknessPlotterButtonFunction
-(void) sickPlottersButtonFunction
{
    NSLog(@"sicknessPlotterButtonFunction");
    [footerDelegate sickPlottersButtonFunction];
}

#pragma mark Change Image
- (void)changeImage : (NSString*)selectedButton
{
    if ([selectedButton isEqualToString:@"1"])
    {
        [myPillButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateNormal];
        [healthCanadaAlertButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [sicknessPlotterButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        
        [myPillButton setImage:[UIImage imageNamed:@"contact_sel.png"] forState:UIControlStateNormal];
        [healthCanadaAlertButton setImage:[UIImage imageNamed:@"recent.png"] forState:UIControlStateNormal];
        [sicknessPlotterButton setImage:[UIImage imageNamed:@"more_iPhone6_grey.png"] forState:UIControlStateNormal];

    }
    else if ([selectedButton isEqualToString:@"2"])
    {
       
        [healthCanadaAlertButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateNormal];
        [myPillButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [sicknessPlotterButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];

        
        [myPillButton setImage:[UIImage imageNamed:@"contact.png"] forState:UIControlStateNormal];
        [healthCanadaAlertButton setImage:[UIImage imageNamed:@"recent_sel.png"] forState:UIControlStateNormal];
        [sicknessPlotterButton setImage:[UIImage imageNamed:@"more_iPhone6_grey.png"] forState:UIControlStateNormal];
        
    }
    else if ([selectedButton isEqualToString:@"3"])
    {
       
        [sicknessPlotterButton setTitleColor:[UIColor colorWithRed:13.0/255 green:121.0/255 blue:255.0/255 alpha:1.0] forState:UIControlStateNormal];
        [myPillButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];
        [healthCanadaAlertButton setTitleColor:[UIColor colorWithRed:146.0/255 green:146.0/255 blue:146.0/255 alpha:1.0] forState:UIControlStateNormal];


        [myPillButton setImage:[UIImage imageNamed:@"contact.png"] forState:UIControlStateNormal];
        [healthCanadaAlertButton setImage:[UIImage imageNamed:@"recent.png"] forState:UIControlStateNormal];
        [sicknessPlotterButton setImage:[UIImage imageNamed:@"more_iPhone6.png"] forState:UIControlStateNormal];
       
    }
}
@end
























