//
//  SicknessPlotterVC.h
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZFPlotChart.h"

@interface SicknessPlotterVC : UIViewController

@property (strong, nonatomic) ZFPlotChart *plotChart;


@end
