//
//  FallDetectionVC.h
//  Vivo
//
//  Created by Sukhreet on 03/11/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FallDetectionVC : UIViewController

@end
