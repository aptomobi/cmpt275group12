//
//  AppDelegate.h
//  Vivo
//
//  Created by Sukhreeton 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTKnockDetector.h"
#import <CoreLocation/CoreLocation.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navController;
@property (nonatomic, strong) HTKnockDetector * knockDetector;
@property(strong,nonatomic)CLLocationManager *locationManager;
@property(strong,nonatomic)CLLocation *currentLocation;
@property(strong,nonatomic)NSTimer *currentCycleTimer;
@property(assign,atomic)BOOL isFakeNotificationEnable;

-(void)functionToHandleInvalidAccessToken;
-(void)showIndicator;
-(void)hideIndicator;
-(void)func_FakeNotification;


@end

AppDelegate *appDelegate(void);
