//
//  main.m
//  Vivo
//
//  Created by Sukhreet on 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
