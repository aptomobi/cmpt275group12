//
//  AppDelegate.m
//  Vivo
//
//  Created by Sukhreet on 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "MBProgressHUD.h"


@interface AppDelegate () <HTKnockDetectorDelegate,CLLocationManagerDelegate>
{
    MBProgressHUD*  HUD;
    BOOL isFallAlertVisible;
}

@end

@implementation AppDelegate

@synthesize locationManager;
@synthesize currentCycleTimer;
@synthesize isFakeNotificationEnable;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    ViewController *_viewVC = [[ViewController alloc]init];
    _navController = [[UINavigationController alloc]initWithRootViewController:_viewVC];
    _navController.navigationBarHidden = YES;
    _navController.navigationBar.tintColor = [UIColor whiteColor];
    self.window.rootViewController = _navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];

    
    self.knockDetector = [[HTKnockDetector alloc] init];
    [self.knockDetector setDelegate:self];
    [self.knockDetector setIsOn:false];
    [self func_AccessLocation];
    
    
//    NSString *_strEmail = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData] valueForKey:@"email"];
//    NSLog(@"_strEmail is %@ and length is %zd and class is %@",_strEmail,_strEmail.length,_strEmail.class);
//    
//    if (_strEmail.length>0)
//    {
//        [currentCycleTimer invalidate];
//        currentCycleTimer = nil;
//        currentCycleTimer = [NSTimer scheduledTimerWithTimeInterval: 3.0 target:self selector:@selector(func_FakeNotification) userInfo:nil repeats: YES];
//    }

    
    
    
    // Remote Notification
    if(launchOptions != nil)
    {
        NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if (userInfo !=nil)
        {
            NSLog(@"userInfo is %@",userInfo);
        }
    }
    
    
    
    // Local Notification
    UILocalNotification *localNotif = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if(localNotif != nil)
    {
        NSDictionary *NotificationValue = [localNotif.userInfo objectForKey:@"localPushNotification"];
        if (NotificationValue !=nil)
        {
            NSLog(@"NotificationValue is %@",NotificationValue);
        }
    }
    
    
    
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge
                                                                                         |UIUserNotificationTypeSound
                                                                                         |UIUserNotificationTypeAlert) categories:nil];
    [application registerUserNotificationSettings:settings];

    
    application.applicationIconBadgeNumber=0;
    [UIApplication sharedApplication].statusBarHidden = NO;
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [UIApplication sharedApplication].networkActivityIndicatorVisible=FALSE;

    return YES;
}


- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    UIApplicationState state = [application applicationState];
    if (state != UIApplicationStateActive)
    {
        NSDictionary *NotificationValue = [notification.userInfo objectForKey:@"localPushNotification"];        //objectForKey:TheKeyNameYouUsed
        NSLog(@"LOCAL NOTIFICATION RECEVIED, value: %@", NotificationValue);
    }
    else
    {
        //[UIFunction func_AlertWithTitle:@"Notification" andMessage:@"You have a schedule pill now."];
        UIAlertView *_alert = [[UIAlertView alloc]initWithTitle:@"Notification" message:@"Have you taken your pill?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
        _alert.tag = 4949;
        [_alert show];
    }
}



- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    UIApplicationState state = [application applicationState];
    if (state != UIApplicationStateActive )
    {
        NSLog(@"userInfo is %@",userInfo);
        
    }
    else
    {
        // APP IS IN ACTIVE STATE
        
        NSLog(@"userInfo is %@",userInfo);
        
    }
}


- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}


- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"])
    {
    }
    else if ([identifier isEqualToString:@"answerAction"])
    {
    }
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString* newToken = [deviceToken description];
    newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    if(![[NSUserDefaults standardUserDefaults] objectForKey:@"device_token"])
    {
        [[NSUserDefaults standardUserDefaults] setValue:newToken forKey:@"device_token"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        NSLog(@"DEVICE TOKEN IS %@",[[NSUserDefaults standardUserDefaults] valueForKey:@"device_token"] );
    }
}







- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark
#pragma mark functionToHandleInvalidAccessToken
-(void)functionToHandleInvalidAccessToken
{
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    NSString *token ;
    token = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"device_token"]];
    
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath =  [documentsDirectory stringByAppendingPathComponent:@"Vivo.db"];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        NSLog(@"DATABASE REMOVED");
    }
    
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    ViewController *_viewVC = [[ViewController alloc]init];
    _navController = [[UINavigationController alloc]initWithRootViewController:_viewVC];
    _navController.navigationBarHidden = YES;
    _navController.navigationBar.tintColor = [UIColor whiteColor];
    self.window.rootViewController = _navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
}

-(void)showIndicator
{
    if(HUD == nil)
    {
        HUD = [[MBProgressHUD alloc] initWithView:self.window];
        HUD.labelText = @"Loading...";
    }
    
    [self.window addSubview:HUD];
    [HUD show:YES];
}

-(void)hideIndicator
{
    [HUD hide:YES];
    [HUD removeFromSuperview];
}


#pragma mark
#pragma mark Knock Detector Delegate
-(void)knockDetectorDetectedKnock:(HTKnockDetector*)detector atTime:(NSTimeInterval)time
{
    if (isFallAlertVisible == NO)
    {
        isFallAlertVisible = YES;
        
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle:@"Fall Detection" message:@"Are you OK ?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
        alert.tag = 5050;
        [alert show];

    }
}

#pragma mark
#pragma mark Alert Delegates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 4949 && buttonIndex == 1)
    {
        NSLog(@"API Call for Push Notification _____ Pill");
        [self func_APIPushNotification : @"pill"];
    }
    else if (alertView.tag == 5050)
    {
        isFallAlertVisible = NO;

        if (buttonIndex == 0)
        {
            NSLog(@"API Call for Push Notification ___ Fall Detection");
            [self func_APIPushNotification : @"fall"];
        }
    }
}

-(void)func_APIPushNotification : (NSString*)type
{
    if ([type isEqualToString:@"pill"])
    {
        Reachability *reach = [Reachability reachabilityForInternetConnection];
        NetworkStatus netStatus = [reach currentReachabilityStatus];
        
        if (netStatus == NotReachable)
        {
            [UIFunction func_Alert_InternetUnavailable];
        }
        else
        {
            NSLog(@"Call API For Push");
            
            [appDelegate() showIndicator];
            
            NSString *_strEmail = [NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData] valueForKey:@"email"]];
            NSString *_strLoad = [NSString stringWithFormat:@"ALERT! %@ has taken pill.",_strEmail];
            
            
            ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/notifyin.php"]]];
            [Request setTimeOutSeconds:300];
            Request.shouldAttemptPersistentConnection   = NO;
            Request.delegate=self;
            [Request setRequestMethod:@"POST"];
            [Request setPostValue:_strEmail forKey:@"email"];
            [Request setPostValue:_strLoad forKey:@"load"];
            Request.tag = 364789;
            [Request startAsynchronous];
        }
    }
    else if ([type isEqualToString:@"fall"])
    {
        Reachability *reach = [Reachability reachabilityForInternetConnection];
        NetworkStatus netStatus = [reach currentReachabilityStatus];
        
        if (netStatus == NotReachable)
        {
            [UIFunction func_Alert_InternetUnavailable];
        }
        else
        {
            NSLog(@"Call API For Push");
            
            [appDelegate() showIndicator];
            
            NSString *_strEmail = [NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData] valueForKey:@"email"]];
            NSString *_strLatitude = [[NSUserDefaults standardUserDefaults] valueForKey:kUserCurrentLatitude];
            NSString *_strLongitude = [[NSUserDefaults standardUserDefaults] valueForKey:kUserCurrentLongitude];
            
            if (_strLatitude.length == 0)
            {
                _strLatitude = @"";
            }
            
            if (_strLongitude.length == 0)
            {
                _strLongitude = @"";
            }
            
            
            NSString *_strLoad = [NSString stringWithFormat:@"ALERT! %@ has fallen at location: %@ , %@.",_strEmail,_strLatitude,_strLongitude];
            
            ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/notifyin.php"]]];
            [Request setTimeOutSeconds:300];
            Request.shouldAttemptPersistentConnection   = NO;
            Request.delegate=self;
            [Request setRequestMethod:@"POST"];
            [Request setPostValue:_strEmail forKey:@"email"];
            [Request setPostValue:_strLoad forKey:@"load"];
            Request.tag = 364789;
            [Request startAsynchronous];
        }
    }
}

#pragma mark
#pragma mark **************** AccessLocation and Its Delegates ****************
-(void)func_AccessLocation
{
    locationManager = nil;
    locationManager = [[CLLocationManager alloc]init];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0 && [CLLocationManager authorizationStatus] != kCLAuthorizationStatusAuthorizedWhenInUse)
    {
        [locationManager requestWhenInUseAuthorization];
    }
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];
}


- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *location = [locations lastObject];
    NSString *currentLatitude = [NSString stringWithFormat:@"%f",location.coordinate.latitude];
    NSString *currentLongitude = [NSString stringWithFormat:@"%f",location.coordinate.longitude];
    
    if (currentLatitude.length==0)
    {
        currentLatitude = @"";
    }
    
    if (currentLongitude.length==0)
    {
        currentLongitude = @"";
    }
    
    [[NSUserDefaults standardUserDefaults]setObject:currentLatitude forKey:kUserCurrentLatitude];
    [[NSUserDefaults standardUserDefaults]setObject:currentLongitude forKey:kUserCurrentLongitude];
    [[NSUserDefaults standardUserDefaults]synchronize];
}

-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status)
    {
        case kCLAuthorizationStatusNotDetermined:
        case kCLAuthorizationStatusRestricted:
        case kCLAuthorizationStatusDenied:
        {
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0 && [CLLocationManager authorizationStatus] != kCLAuthorizationStatusAuthorizedWhenInUse)
            {
                [locationManager requestWhenInUseAuthorization];
            }
            else
            {
                [locationManager startUpdatingLocation];
            }
        }
            break;
        default:
        {
            [locationManager startUpdatingLocation];
        }
            break;
    }
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if ([error code] == kCLErrorDenied)
    {
        //you had denied
        NSLog(@"YOU HAVE DENIED PERMISSIONS. Error while getting core location : %@",[error localizedFailureReason]);
    }
}


#pragma mark
#pragma mark func_FakeNotification
-(void)func_FakeNotification
{
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    
    if (netStatus == NotReachable)
    {}
    else
    {
        NSString *_strEmail = [NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData] valueForKey:@"email"]];
        
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/notifyout.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:_strEmail forKey:@"email"];
        Request.tag = 121121;
        [Request startAsynchronous];
    }
}



#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 364789) // pill api push notification
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json to pill api push notification %@",json);
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
    
    else if (request.tag == 121121) // fake notification api
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json fake notification %@",json);
            
            if ([json objectForKey:@"error"])
            {
                
            }
            else if ([json objectForKey:@"response"])
            {
                [UIFunction func_AlertWithTitle:@"Notification" andMessage:[[json objectForKey:@"response"] valueForKey:@"notify"]];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }

    }
}

@end

AppDelegate *appDelegate(void){
    
    return (AppDelegate*)[UIApplication sharedApplication].delegate;
}

