//
//  LogInVC.m
//  Vivo
//
//  Created by Sukhreet on 30/10/15.
//  Copyright © 2015 Apto. All rights reserved.
//  Comment eidted by Hong
//  
// -----------------------------------------------------
// login view controller
// under this VC, user can login or creat a new account
// -----------------------------------------------------
#import "LogInVC.h"
#import "MyPillVC.h"

@interface LogInVC () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@end

@implementation LogInVC
{
    // store login information
    NSMutableDictionary *_dictinaryLogIn;
    // keys for dictionary
    NSMutableArray *_arrayOfKeys;
    // login UItabletview
    UITableView *_tableViewLogIn;
    // email string to server
    NSString *_strEmailToServer;
    // password to server
    NSString *_strPasswordoServer;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // draw background
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_img.png"]];
    // init dictionary
    _dictinaryLogIn = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                        @"",@"Email",
                        @"",@"Password",
                        nil];
    // init key array
    _arrayOfKeys = [[NSMutableArray alloc]initWithObjects:@"Email",@"Password", nil];

    // draw logo and add subview
    UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(self.view.frame.size.width/2.0-[UIImage imageNamed:@"logo.png"].size.width/2.0, 50, [UIImage imageNamed:@"logo.png"].size.width, [UIImage imageNamed:@"logo.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo.png"] isLogo:NO];
    [self.view addSubview:_imgViewLogo];
    
    // UITable View which contains all Field
    _tableViewLogIn = [self createTableView:CGRectMake(20,_imgViewLogo.frame.size.height+_imgViewLogo.frame.origin.y+70, self.view.frame.size.width-40, 100) backgroundColor:[UIColor whiteColor]];
    _tableViewLogIn.showsVerticalScrollIndicator = YES;
    _tableViewLogIn.layer.cornerRadius = 5.0;
    [self.view addSubview:_tableViewLogIn];
    
    // draw login button
    UIButton *_btnLogIn = [UIFunction createButton:CGRectMake(_tableViewLogIn.frame.origin.x, _tableViewLogIn.frame.size.height+_tableViewLogIn.frame.origin.y+10, _tableViewLogIn.frame.size.width, 50) bckgroundColor:[UIColor whiteColor] image:nil title:@"LogIn" font:[UIFont fontWithName:miscoRegular size:18.0] titleColor:[UIColor colorWithRed:15.0/255 green:73.0/255 blue:136.0/255 alpha:1.0]];
    _btnLogIn.layer.cornerRadius = 5.0;
    [_btnLogIn addTarget:self action:@selector(func_LogIn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_btnLogIn];
    
    // UIlable Not a member?
    UILabel *_lblNotAMember = [UIFunction createLable:CGRectMake(_tableViewLogIn.frame.origin.x+50, self.view.frame.size.height-55, 150, 50) bckgroundColor:[UIColor clearColor] title:@"Not a member ?" font:[UIFont fontWithName:miscoRegular size:18.0] titleColor:[UIColor whiteColor]];
    _lblNotAMember.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:_lblNotAMember];
    
    // signup button
    UIButton *_btnSignUp = [UIFunction createButton:CGRectMake(_lblNotAMember.frame.origin.x+_lblNotAMember.frame.size.width, _lblNotAMember.frame.origin.y+10, 70, 30) bckgroundColor:[UIColor clearColor] image:nil title:@"Sign Up" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _btnSignUp.layer.cornerRadius = 5.0;
    
    // action or signup button
    [_btnSignUp addTarget:self action:@selector(func_SignUp) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_btnSignUp];
    
    // blank box divid login and signup
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(_btnSignUp.frame.origin.x+5, _btnSignUp.frame.size.height+_btnSignUp.frame.origin.y, _btnSignUp.frame.size.width-10, 1) bckgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_viewDivider];


    
}

#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

// go back to signup
-(void)func_SignUp
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark Table View Data Source and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[_dictinaryLogIn allKeys] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    
    NSString *_strKey = [NSString stringWithFormat:@"%@",[_arrayOfKeys objectAtIndex:indexPath.row]];
    
    UITextField *_textField = [[UITextField alloc]init];
    _textField.frame = CGRectMake(25, 0, tableView.frame.size.width-50, 50);
    _textField.borderStyle = UITextBorderStyleNone;
    _textField.font = [UIFont fontWithName:miscoRegular size:16];
    _textField.keyboardType = UIKeyboardTypeDefault;
    _textField.returnKeyType = UIReturnKeyDone;
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textField.tag = indexPath.row+100;
    _textField.text = [_dictinaryLogIn valueForKey:_strKey];
    _textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    _textField.delegate = self;
    _textField.secureTextEntry = NO;
    _textField.placeholder = _strKey;
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.textColor = [UIColor blackColor];
    _textField.leftViewMode=UITextFieldViewModeAlways;
    _textField.autocapitalizationType= UITextAutocapitalizationTypeNone;
    _textField.autocorrectionType = UITextAutocorrectionTypeNo;
    _textField.backgroundColor = [UIColor clearColor];
    [self.view endEditing:YES];
    [cell.contentView addSubview:_textField];
    
    if (_textField.tag == 102 || _textField.tag == 103)
    {
        _textField.secureTextEntry = YES;
    }
    
    
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(_textField.frame.origin.x, frame.size.height-1, _textField.frame.size.width, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;
    
}




#pragma mark
#pragma mark TextField Delegate
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 100) //email
    {
        NSString *_strEmail = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictinaryLogIn setValue:_strEmail forKey:@"Email"];
    }
    else if (textField.tag == 101) // password
    {
        NSString *_strPassword = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictinaryLogIn setValue:_strPassword forKey:@"Password"];
    }
    
    return YES;
}


- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    if (textField.tag == 100) //email
    {
        [_dictinaryLogIn setValue:@"" forKey:@"Email"];
    }
    else if (textField.tag == 101) // user_name
    {
        [_dictinaryLogIn setValue:@"" forKey:@"Password"];
    }
    return YES;
}



#pragma mark
#pragma mark func_LogIn
-(void)func_LogIn
{
    NSLog(@"func_LogIn is %@",_dictinaryLogIn);
    
    
    _strEmailToServer = [[_dictinaryLogIn valueForKey:@"Email"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    _strPasswordoServer = [[_dictinaryLogIn valueForKey:@"Password"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    
    if (_strEmailToServer.length == 0)
    {
        [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please enter your e-mail address."];
    }
    else if ([UIFunction validateEmail:_strEmailToServer] == 0)
    {
        [UIFunction func_AlertWithTitle:@"Error" andMessage:@"Please enter a valid e-mail address."];
    }
    else if (_strPasswordoServer.length == 0)
    {
        [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please enter Password."];
    }
    else
    {
        [self.view endEditing:YES];
        // call api to log in
        
        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/loginV2.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:_strEmailToServer forKey:@"email"];
        [Request setPostValue:_strPasswordoServer forKey:@"password"];
        Request.tag = 45454645;
        [Request startAsynchronous];
    }
}

#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 45454645) // login
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json to get register user %@",json);
            
            if ([json objectForKey:@"response"])
            {
                
                NSMutableDictionary *_dictionaryTemp = [[NSMutableDictionary alloc]init];
                if ([[json objectForKey:@"response"]valueForKey:@"contact"])
                {
                    [_dictionaryTemp setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"]valueForKey:@"contact"]] forKey:@"contact"];
                }
                else
                {
                    [_dictionaryTemp setObject:@"" forKey:@"contact"];
                }
                
                [_dictionaryTemp setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"]valueForKey:@"device_token"]] forKey:@"device_token"];
                [_dictionaryTemp setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"]valueForKey:@"email"]] forKey:@"email"];
                [_dictionaryTemp setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"]valueForKey:@"location"]] forKey:@"location"];
                [_dictionaryTemp setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"]valueForKey:@"password"]] forKey:@"password"];

                
                [[NSUserDefaults standardUserDefaults]setObject:_dictionaryTemp forKey:kLoginData];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                MyPillVC *myPill = [[MyPillVC alloc]init];
                [self.navigationController pushViewController:myPill animated:YES];
            }
            else if ([json objectForKey:@"error"])
            {
                [UIFunction func_AlertWithTitle:@"Error" andMessage:[json objectForKey:@"error"]];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
