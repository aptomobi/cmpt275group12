<?php

echo "Hey there. the server is located on AWS, and was configured on Sunday October 11th, 2015." 

?>
