//
//  SideMenu.m
//  DocSnap
//
//  Created by Sukhreet on 05/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "SideMenu.h"

@implementation SideMenu
{
    UIView *mainView;
    UIView *_tapableView;
    BOOL isEditModeEnable;
}
@synthesize sideMenuDelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backgroundColor =[UIColor colorWithRed:0.0/255 green:0.0/255 blue:0.0/255 alpha:0.1];
        self.frame = CGRectMake(0, 0, 375.0, 667.0);
        
        
        mainView = [[UIView alloc]init];
        mainView.backgroundColor = [UIColor whiteColor];
        mainView.frame = CGRectMake(-self.frame.size.width, 0, self.frame.size.width, self.frame.size.height);
        [self addSubview:mainView];
        
        [UIView animateWithDuration:.3f animations:^{
            
            mainView.frame = CGRectMake(0, 0, self.frame.size.width-70, self.frame.size.height);
            self.backgroundColor = [UIColor colorWithRed:0.0/255 green:0.0/255 blue:0.0/255 alpha:0.4];
            
        } completion:^(BOOL finished) {
        }];
        
        
        
        UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, mainView.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
        [mainView addSubview:_viewHeader];
        
        UIButton *_btnSideMenu = [UIFunction createButton:CGRectMake(10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] title:nil font:nil titleColor:nil];
        _btnSideMenu.userInteractionEnabled = false;
        [_viewHeader addSubview:_btnSideMenu];
        
        
        _tapableView = [[UIView alloc]init];
        _tapableView.backgroundColor = [UIColor clearColor];
        _tapableView.frame = CGRectMake(mainView.frame.size.width+mainView.frame.origin.x, 0, self.frame.size.width-mainView.frame.size.width-mainView.frame.origin.x, self.frame.size.height);
        UITapGestureRecognizer *tapToRemoveAlert = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(func_SideMenu_RemoveSideMenu)];
        [_tapableView addGestureRecognizer:tapToRemoveAlert];
        [self addSubview:_tapableView];
        
        
        UIButton *_btnSettings = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnSettings.frame = CGRectMake(10, 70, mainView.frame.size.width-20, 50);
        [_btnSettings setTitle:@"Settings" forState:UIControlStateNormal];
        [_btnSettings setTitleColor:[UIColor colorWithRed:60.0/255 green:60.0/255 blue:60.0/255 alpha:1.0] forState:UIControlStateNormal];
        _btnSettings.titleLabel.font = [UIFont fontWithName:miscoBold size:16.0];
        [_btnSettings addTarget:self action:@selector(func_SideMenu_Settings) forControlEvents:UIControlEventTouchUpInside];
        [_btnSettings setImage:[UIImage imageNamed:@"setting.png"] forState:UIControlStateNormal];
        [mainView addSubview:_btnSettings];
        
        
        _btnSettings.imageEdgeInsets = UIEdgeInsetsMake(0, -190, 0, 0);
        _btnSettings.titleEdgeInsets = UIEdgeInsetsMake(0, -185, 0, 0);
        

        
        UIButton *_btnLogOut = [UIFunction createButton:CGRectMake(10, _btnSettings.frame.size.height+_btnSettings.frame.origin.y, mainView.frame.size.width-20, 50) bckgroundColor:[UIColor redColor] image:nil title:@"LogOut" font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
        _btnLogOut.layer.cornerRadius = 5.0;
        [_btnLogOut addTarget:self action:@selector(func_SideMenu_LogOut) forControlEvents:UIControlEventTouchUpInside];
        [mainView addSubview:_btnLogOut];
        
    }
    
    return self;
}



#pragma mark
#pragma mark ************************************************************ Side Menu Delegates ************************************************************

-(void)func_SideMenu_RemoveSideMenu
{
    [UIView animateWithDuration:.3f animations:^{
        mainView.frame = CGRectMake(-self.frame.size.width, 0, self.frame.size.width, self.frame.size.height);
        self.backgroundColor = [UIColor colorWithRed:0.0/255 green:0.0/255 blue:0.0/255 alpha:0];
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}



- (void)func_SideMenu_Settings
{
    [self func_SideMenu_RemoveSideMenu];
    [sideMenuDelegate func_SideMenu_Settings];
}

- (void)func_SideMenu_LogOut
{
    [self func_SideMenu_RemoveSideMenu];
    [sideMenuDelegate func_SideMenu_LogOut];
}



@end
