//
//  SideMenu.h
//  DocSnap
//
//  Created by Sukhreet on 05/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol sideMenuProtocol;
@interface SideMenu : UIView 
{
    id <sideMenuProtocol> sideMenuDelegate;
}

-(void) func_SideMenu_RemoveSideMenu;

@property (retain) id<sideMenuProtocol> sideMenuDelegate;
@end


@protocol sideMenuProtocol <NSObject>
- (void)func_SideMenu_Settings;
- (void)func_SideMenu_LogOut;

@end

