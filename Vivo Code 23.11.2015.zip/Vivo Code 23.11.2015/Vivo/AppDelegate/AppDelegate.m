//
//  AppDelegate.m
//  Vivo
//
//  Created by Sukhreet on 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "MBProgressHUD.h"


@interface AppDelegate () <HTKnockDetectorDelegate>
{
    MBProgressHUD*  HUD;
}

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    ViewController *_viewVC = [[ViewController alloc]init];
    _navController = [[UINavigationController alloc]initWithRootViewController:_viewVC];
    _navController.navigationBarHidden = YES;
    _navController.navigationBar.tintColor = [UIColor whiteColor];
    self.window.rootViewController = _navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];

    
    self.knockDetector = [[HTKnockDetector alloc] init];
    [self.knockDetector setDelegate:self];
    [self.knockDetector setIsOn:true];
    
    
    // Remote Notification
    if(launchOptions != nil)
    {
        NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if (userInfo !=nil)
        {
            NSLog(@"userInfo is %@",userInfo);
        }
    }
    
    
    
    // Local Notification
    UILocalNotification *localNotif = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if(localNotif != nil)
    {
        NSDictionary *NotificationValue = [localNotif.userInfo objectForKey:@"localPushNotification"];
        if (NotificationValue !=nil)
        {
            NSLog(@"NotificationValue is %@",NotificationValue);
        }
    }
    
    
    
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge
                                                                                         |UIUserNotificationTypeSound
                                                                                         |UIUserNotificationTypeAlert) categories:nil];
    [application registerUserNotificationSettings:settings];

    
    application.applicationIconBadgeNumber=0;
    [UIApplication sharedApplication].statusBarHidden = NO;
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [UIApplication sharedApplication].networkActivityIndicatorVisible=FALSE;

    return YES;
}


- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    UIApplicationState state = [application applicationState];
    if (state != UIApplicationStateActive)
    {
        NSDictionary *NotificationValue = [notification.userInfo objectForKey:@"localPushNotification"];        //objectForKey:TheKeyNameYouUsed
        NSLog(@"LOCAL NOTIFICATION RECEVIED, value: %@", NotificationValue);
    }
    else
    {
        [UIFunction func_AlertWithTitle:@"Notification" andMessage:@"You have a schedule pill now."];
//        UIAlertView *_alert = [[UIAlertView alloc]initWithTitle:@"Notification" message:@"Have you taken your pill?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
//        _alert.tag = 4949;
//        [_alert show];
    }
}

#pragma mark
#pragma mark Alert Delegates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 4949 && buttonIndex == 1)
    {
        NSLog(@"API Call for Push Notification");
    }
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    UIApplicationState state = [application applicationState];
    if (state != UIApplicationStateActive )
    {
        NSLog(@"userInfo is %@",userInfo);
        
    }
    else
    {
        // APP IS IN ACTIVE STATE
        
        NSLog(@"userInfo is %@",userInfo);
        
    }
}


- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}


- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"])
    {
    }
    else if ([identifier isEqualToString:@"answerAction"])
    {
    }
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString* newToken = [deviceToken description];
    newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    if(![[NSUserDefaults standardUserDefaults] objectForKey:@"device_token"])
    {
        [[NSUserDefaults standardUserDefaults] setValue:newToken forKey:@"device_token"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        NSLog(@"DEVICE TOKEN IS %@",[[NSUserDefaults standardUserDefaults] valueForKey:@"device_token"] );
    }
}







- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark
#pragma mark functionToHandleInvalidAccessToken
-(void)functionToHandleInvalidAccessToken
{
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    NSString *token ;
    token = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"device_token"]];
    
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath =  [documentsDirectory stringByAppendingPathComponent:@"Vivo.db"];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        NSLog(@"DATABASE REMOVED");
    }
    
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    ViewController *_viewVC = [[ViewController alloc]init];
    _navController = [[UINavigationController alloc]initWithRootViewController:_viewVC];
    _navController.navigationBarHidden = YES;
    _navController.navigationBar.tintColor = [UIColor whiteColor];
    self.window.rootViewController = _navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
}

-(void)showIndicator
{
    if(HUD == nil)
    {
        HUD = [[MBProgressHUD alloc] initWithView:self.window];
        HUD.labelText = @"Loading...";
    }
    
    [self.window addSubview:HUD];
    [HUD show:YES];
}

-(void)hideIndicator
{
    [HUD hide:YES];
    [HUD removeFromSuperview];
}


#pragma mark
#pragma mark Knock Detector Delegate
-(void)knockDetectorDetectedKnock:(HTKnockDetector*)detector atTime:(NSTimeInterval)time
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:@"Fall Detection" message:@"Are you OK ?" delegate:nil cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
    [alert show];
}



@end

AppDelegate *appDelegate(void){
    
    return (AppDelegate*)[UIApplication sharedApplication].delegate;
}

